


__author__ = "John Boqiang Hu"
__copyright__ = "Copyright 2015, Peking University."
__credits__ = [ ]
__license__ = "GPL"
__version__ = "2.0.1"
__maintainer__ = "John Boqiang Hu"
__email__ = "huboqiang@gmail.com"
__status__ = "Production"
__all__ = ["frame", "settings", "utils"]