#python run_mRNA_UMI.py --ref hg19 GS_1_24.xls
#python run_mRNA_UMI.py --ref hg19 GS_abcd_20160506.xls
#python run_mRNA_UMI.py --ref hg19 GS_es_stom_LSI_20160506.xls
#python run_mRNA_UMI.py --ref hg19 GS_e_20160522.xls
#python run_mRNA_UMI.py --ref hg19 GS_f_20160526.xls
python run_mRNA_UMI.py --ref hg19 20160702HE11W_PFC1.xls
